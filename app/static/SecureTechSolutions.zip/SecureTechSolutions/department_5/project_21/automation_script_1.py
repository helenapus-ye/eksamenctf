#python3

print('Welcome to Secure Tech Solutions!')
